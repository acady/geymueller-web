jQuery(document).ready(function($){
		$('.carousel').carousel({
		interval: 3000
	})						
 });