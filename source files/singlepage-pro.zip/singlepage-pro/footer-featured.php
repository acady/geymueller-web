<div id="footer" style=" display:none;">
<span id="copyright"><?php echo of_get_option('copyright','&copy; 2015, Powered by <a href="http://wordpress.org/">WordPress</a>. Designed by <a href="http://www.hoosoft.com/">Hoo Themes</a>.');?></span>
        </div>
       <?php wp_footer();?>
</body>
</html>