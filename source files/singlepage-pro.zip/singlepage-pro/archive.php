<?php
/**
 * The blog list template file.
 *
 * @since singlepage 2.4.3
 */

get_header(); ?>
<?php					
get_template_part("content","blog-list");
 ?>
<?php get_footer(); ?>