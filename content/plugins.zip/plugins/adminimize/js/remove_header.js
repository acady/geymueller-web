/**
 * remove header
 */
jQuery(document).ready(function() {
	jQuery('#wphead').remove();
});
